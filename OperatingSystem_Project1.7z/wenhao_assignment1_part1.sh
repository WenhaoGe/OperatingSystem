compute_fraction(){
	# $1:number of processes
	# $2: expected cpu utilization
	
	result=$(awk "BEGIN { print (1 - $2) ** (1 / $1) }")
	echo "RESULT: The I/O fraction time is: $result "
	
}

echo "Enter the number of processes(integer in range of 0 to 10)"
	 read COUNTER;

while true; do
	
	if [ $COUNTER -eq $COUNTER 2>/dev/null ]; then
		if [[ ("$COUNTER" -gt 0 && "$COUNTER" -le 10)]];then
			break
		else
			echo "ERROR: invalid input. it should be in range of 0 and 10"
			read COUNTER
		fi
	else
		echo "ERROR: invalid input. it should be an integer"
		read COUNTER
	fi
done

echo "Number of processes: $COUNTER"


while true; do
	result1="0"
	result2="1"
	 echo "Enter the expected cpu utilization(in range 0 to 1): "
	 read z;
	
	 if [ $(bc <<< "$z >= $result1") -eq 1 ] && [ $(bc <<< "$z <= $result2") -eq 1 ]; 
	 then
	   break
	 fi
done

compute_fraction $COUNTER $z
