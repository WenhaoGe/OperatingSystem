function empty () {
	

	if [[ -z $1 ]]; then
		result=1 # Input variable is empty
	else
		result=0 # Input variable is not empty
	fi
}

echo "Enter the number of jobs(integer in range of 0 to 10)"
	 read NUMBER_OF_PROCESSES;

while true; do
	
		if [ $NUMBER_OF_PROCESSES -eq $NUMBER_OF_PROCESSES 2>/dev/null ]; then
			if [[("NUMBER_OF_PROCESSES" -ge 0&& "$NUMBER_OF_PROCESSES" -le 10)]];then
				break
			else
				echo "ERROR: invalid input. It should be within 0 and 10"
				read NUMBER_OF_PROCESSES
			fi
		else
			echo "ERROR:invalid input. It should be integer"
			read NUMBER_OF_PROCESSES
		fi
	
done

echo "number of jobs is: $NUMBER_OF_PROCESSES"
echo "***************************"

ARR=()
i=0
echo "enter run time for each job(integers): "
for ((i=0;i<$NUMBER_OF_PROCESSES;i++))
do
	while [ 1 ];do
		read run_time
		if [ $run_time -eq $run_time 2>/dev/null ]; then
			ARR+=($run_time)
			break
		else
			echo "ERROR:invalid input. run time should be integers"
		fi
	done
done

# Now do the Sorting of numbers
for (( i = 0; i < $NUMBER_OF_PROCESSES ; i++ ))
do
	for (( j = $i; j < $NUMBER_OF_PROCESSES; j++ ))
	do
	if [ ${ARR[$i]} -gt ${ARR[$j]}  ]; then
		t=${ARR[$i]}
		ARR[$i]=${ARR[$j]}
		ARR[$j]=$t
	fi
	done
done
# Printing the sorted number
echo -e "\norder of jobs that minimize the waiting time: "
for (( i=0; i < $NUMBER_OF_PROCESSES; i++ ))
	do
		echo ${ARR[$i]}
	done

	echo "****************************"
MIN_WAIT=0
echo "Minimum waiting time is: "

for((i=1;i<$NUMBER_OF_PROCESSES;i++))
do
	for((j=1;j<=i;j++))
	do
		#let "MIN_WAIT = MIN_WAIT + ${SORTED_ARR[j-1]}"
		var1=${ARR[j-1]}
		MIN_WAIT=$(($MIN_WAIT+$var1))
    	
	done
done

echo $MIN_WAIT



